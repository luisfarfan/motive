// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "frame_bridge.h"
#include "fixed_frame_file.hpp"
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <vector>
#include <chrono>
#include <fcntl.h>
#include <fstream>
#include <string>
#include <thread>
#include <unistd.h>

inline uint64_t MonotonicNs() {
  return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());
}
// Two bounded disk samples plus an optional fixed visual sample; one lease.
// No queue or extra pixel copy; optional capture is a fixture observation only.
// Files live in a fresh 0700 directory owned by this launch. No package paths.
class FrameConsumer {
 public:
  FrameConsumer(MotiveFrameBridge* mailbox,const std::string& root,std::atomic<uint64_t>* visual_after=nullptr,unsigned delay_ms=0):mailbox_(mailbox),root_(root),visual_after_(visual_after),delay_ms_(delay_ms) {
    dir_=open(root.c_str(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    if(dir_<0)return;
    first_=openat(dir_,"first.bgra",O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    latest_=openat(dir_,"latest.bgra",O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    if(first_<0||latest_<0)return;
    valid_=true;
    thread_=std::thread([this](){Run();});
  }
  ~FrameConsumer(){Stop();if(first_>=0)close(first_);if(latest_>=0)close(latest_);if(visual_>=0)close(visual_);if(dir_>=0)close(dir_);}
  bool valid()const{return valid_;}
  void Stop(){stop_.store(true);if(thread_.joinable())thread_.join();}
  bool WriteReport(uint64_t callbacks,uint64_t busy,uint64_t invalid,uint64_t max_publish_ns) {
    Stop();
    if(!seen_||failed_)return false;
    return (!visual_seen_||WriteMetadata("visual.json",visual_meta_))&&WriteMetadata("first.json",first_meta_)&&WriteMetadata("latest.json",latest_meta_)&&WriteTelemetry(callbacks,busy,invalid,max_publish_ns);
  }
 private:
  bool WritePixels(int fd,const uint8_t* bytes,size_t n) {
    size_t offset=0;
    while(offset<n){auto count=pwrite(fd,bytes+offset,n-offset,off_t(offset));if(count<0&&errno==EINTR)continue;if(count<=0)return false;offset+=size_t(count);}
    return ftruncate(fd,off_t(n))==0;
  }
  bool WriteMetadata(const char* filename,const MotiveFrameMetadata& m) {
    const int fd=openat(dir_,filename,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    if(fd<0)return false;
    // Internal integers only; no renderer-supplied diagnostics/strings are serialized.
    const std::string json="{\"native_executed\":true,\"instance\":"+std::to_string(m.instance)+",\"generation\":"+std::to_string(m.generation)+",\"epoch\":"+std::to_string(m.epoch)+",\"index\":"+std::to_string(m.index)+",\"observed_ns\":"+std::to_string(m.observed_ns)+",\"width\":"+std::to_string(m.width)+",\"height\":"+std::to_string(m.height)+",\"stride\":"+std::to_string(m.stride)+",\"bgra8\":true,\"alpha_verified\":false,\"acquired\":"+std::to_string(seen_)+",\"max_disk_consumer_ns\":"+std::to_string(max_disk_consumer_ns_)+",\"sandbox_verified\":false,\"helper_cleanup_verified\":false}\n";
    const bool ok=WritePixels(fd,reinterpret_cast<const uint8_t*>(json.data()),json.size());close(fd);return ok;
  }
  bool WriteTelemetry(uint64_t callbacks,uint64_t busy,uint64_t invalid,uint64_t max_publish_ns) {
    const int fd=openat(dir_,"frames.json",O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    if(fd<0)return false;
    MotiveFrameStatistics stats{};if(!motive_frames_stats(mailbox_,&stats)){close(fd);return false;}
    std::string json="{\"native_executed\":true,\"paints\":"+std::to_string(stats.paints)+",\"coalesced\":"+std::to_string(stats.coalesced)+",\"acquired\":"+std::to_string(stats.acquired)+",\"stale\":"+std::to_string(stats.stale)+",\"samples\":[";
    for(size_t i=0;i<samples_.size();++i){const auto& sample=samples_[i];if(i)json+=',';json+="["+std::to_string(sample.index)+","+std::to_string(sample.observed)+","+std::to_string(sample.acquired)+","+std::to_string(sample.transfer)+"]";}
    MotiveFrameStatisticsV2 v2{};
    if(!motive_frames_stats_v2(mailbox_,&v2)){close(fd);return false;}
    json+="],\"accounting_v2\":{\"paints\":"+std::to_string(v2.paints)+",\"coalesced\":"+std::to_string(v2.coalesced)+",\"acquired\":"+std::to_string(v2.acquired)+",\"stale\":"+std::to_string(v2.stale)+",\"pending\":"+std::to_string(v2.pending)+",\"leased\":"+std::to_string(v2.leased)+",\"consumed\":"+std::to_string(v2.consumed)+",\"released_unconsumed\":"+std::to_string(v2.released_unconsumed)+",\"invalidated_close\":"+std::to_string(v2.invalidated_close)+",\"revoked_generation\":"+std::to_string(v2.revoked_generation)+",\"retained_leases\":"+std::to_string(v2.retained_leases)+",\"retained_bytes\":"+std::to_string(v2.retained_bytes)+",\"copied_bytes\":"+std::to_string(v2.copied_bytes)+",\"copy_ns\":"+std::to_string(v2.copy_ns)+",\"publish_busy\":"+std::to_string(v2.publish_busy)+",\"acquire_busy\":"+std::to_string(v2.acquire_busy)+",\"consumer_busy\":"+std::to_string(v2.consumer_busy)+"},\"configured_consumer_delay_ms\":"+std::to_string(delay_ms_)+",\"onpaint_callbacks\":"+std::to_string(callbacks)+",\"onpaint_busy\":"+std::to_string(busy)+",\"onpaint_invalid\":"+std::to_string(invalid)+",\"max_publish_callback_ns\":"+std::to_string(max_publish_ns)+",\"samples_truncated\":"+std::string(sample_capacity_drops_?"true":"false")+",\"disk_write_attempts\":"+std::to_string(disk_write_attempts_)+",\"successful_disk_writes\":"+std::to_string(successful_disk_writes_)+",\"completion_rejected\":"+std::to_string(completion_rejected_)+",\"sample_capacity_drops\":"+std::to_string(sample_capacity_drops_)+",\"latest_file_full_writes\":"+std::to_string(latest_file_.full_writes())+",\"latest_file_ftruncate_calls\":"+std::to_string(latest_file_.truncate_calls())+",\"latest_file_rejected_geometry_or_descriptor\":"+std::to_string(latest_file_.rejected())+",\"latest_file_fixed_bytes\":"+std::to_string(latest_file_.length())+"}\n";
    const bool ok=WritePixels(fd,reinterpret_cast<const uint8_t*>(json.data()),json.size());close(fd);return ok;
  }
  void Run() {
    while(!stop_.load()){
      MotiveFrameMetadata meta{};const uint8_t* pixels=nullptr;
      auto* lease=motive_frames_acquire(mailbox_,MonotonicNs(),1000000000,&meta,&pixels);
      if(lease){
        const auto start=MonotonicNs();
        // Diagnostic-only bounded work delay while this owned lease remains live.
        if(delay_ms_)std::this_thread::sleep_for(std::chrono::milliseconds(delay_ms_));
        bool consumed=false;
        if(motive_frames_lease_valid(lease)){
          bool ok=true;
          if(!seen_){ok=WritePixels(first_,pixels,size_t(meta.length));first_meta_=meta;}
          ok=ok&&latest_file_.Write(latest_,pixels,size_t(meta.length));
          latest_meta_=meta;++disk_write_attempts_;
          const auto threshold=visual_after_?visual_after_->load():0;
          if(!visual_seen_&&threshold&&meta.observed_ns>=threshold){
            visual_=openat(dir_,"visual.bgra",O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
            ok=ok&&visual_>=0&&WritePixels(visual_,pixels,size_t(meta.length));visual_meta_=meta;visual_seen_=true;
          }
          if(!ok)failed_=true;
          else {++seen_;++successful_disk_writes_;consumed=motive_frames_complete(lease);if(!consumed)++completion_rejected_;}
        }
        motive_frames_release(lease);
        const auto transfer=MonotonicNs()-start;
        max_disk_consumer_ns_=std::max(max_disk_consumer_ns_,transfer);
        if(consumed){if(samples_.size()<65536)samples_.push_back({meta.index,meta.observed_ns,start,transfer});else ++sample_capacity_drops_;}
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
  }
  FixedFrameFile latest_file_;
  MotiveFrameBridge* mailbox_;
  std::string root_;
  std::atomic<uint64_t>* visual_after_;
  unsigned delay_ms_;
  int dir_=-1,first_=-1,latest_=-1,visual_=-1;
  bool valid_=false,failed_=false,visual_seen_=false;
  std::atomic<bool> stop_{false};
  std::thread thread_;
  uint64_t seen_=0,max_disk_consumer_ns_=0,disk_write_attempts_=0,successful_disk_writes_=0,completion_rejected_=0,sample_capacity_drops_=0;
  MotiveFrameMetadata first_meta_{},latest_meta_{},visual_meta_{};
  struct Sample {uint64_t index,observed,acquired,transfer;};
  std::vector<Sample> samples_;
};
